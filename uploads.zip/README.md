# python_server
 an python backend server, made for study

# python version
 3.10
 >because only below 3.10 can run on python_anywhere
